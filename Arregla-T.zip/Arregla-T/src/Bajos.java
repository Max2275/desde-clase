public  class Bajos {

    protected double Precio;

    protected double longitud;




}
