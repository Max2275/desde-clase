public abstract class Articulos {
    protected
}
