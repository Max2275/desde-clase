public class Pantalones extends Articulos {

    private due




}
